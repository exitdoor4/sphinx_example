#!/usr/bin/env python3

import sys,os
import curses
import subprocess
import configparser


class MainApp:
    def __init__(self, stdscr):
            self.stdscr = stdscr

            self.setup() # 이거 마지막에 해야함 


    def setup(self):
        # 초기 설정
        self.stdscr.nodelay(1)  # 비차단 입력 설정
        self.stdscr.timeout(100)  # 입력 대기 시간 설정 (밀리초)
        curses.curs_set(0)  # 커서 숨기기
        self.stdscr.clear()
        self.stdscr.refresh()
        curses.start_color()
        self.stdscr.keypad( 1 )
        curses.init_pair(1,curses.COLOR_BLACK, curses.COLOR_CYAN)
        self.highlightText = curses.color_pair( 1 )
        self.normalText = curses.A_NORMAL
        self.define_init()
        self.create_windows()
        self.load_initfile()
        self.run()
    
    def run(self):
        # 메인 루프
        while True:

            if self.stdscr.is_wintouched():
                height, width = self.stdscr.getmaxyx()
                if height != self.prev_height or width != self.prev_width:
                    self.refresh_windows()

            key = self.stdscr.getch()
            if  key == ord('q'):
                break

            # 키 입력 처리 및 화면 갱신
            self.handle_key(key)
            self.update_screen()
            curses.napms(100)


    def define_init(self):
        self.cursor_y = 1
        self.first_driver_ui = 1
        self.first_select_ui = 1
        self.first_apply_ui = 1
        self.dts_list = "" * 10
        self.backspace_flag = 0
        self.enter_flag = 0
        self.current_page = 1
        self.log_idx = 0
        self.log_buffer = [""] * 5
        self.change_log_win = 0
        self.output = ""
        self.config_list = []
        self.select_index = 0
        self.file_idx_A = -1
        self.file_idx_B = -1
        self.dual_value = 0
        self.dtb_value = 0
        self.apply_flag = 0
        self.cursor_y_changed = False

    def create_windows(self):
          # 터미널 크기 가져오기
        height, width = self.stdscr.getmaxyx()
        self.prev_height, self.prev_width = self.stdscr.getmaxyx()
        self.stdscr.box()

        status_height = 3 
        log_height = max(3, height // 2)
        main_height = height - status_height - log_height
        # 서브 윈도우 생성
        self.main_win = curses.newwin(main_height, width - 2, 1, 1)
        self.log_win = curses.newwin(log_height - 2, width - 2, main_height + 1 , 1)
        self.status_win = curses.newwin(status_height, width-2, main_height + log_height -1 , 1)

        self.main_win.box()
        self.log_win.box()
        self.main_win.keypad(True)

        self.main_win.addstr(1, 2, "Main" , curses.A_BOLD)
        self.log_win.addstr(1, 2, "Log" , curses.A_BOLD)
        self.status_win.addstr(1, 2, "Status | back F2 | select ENTER" , curses.A_BOLD)
        # 화면 갱신
        self.stdscr.refresh()
        self.main_win.refresh()
        self.log_win.refresh()
        self.status_win.refresh()

        self.log_print("create OK")

    def handle_key(self, key):

        old_cursor_y = self.cursor_y

        if key == curses.KEY_UP and self.cursor_y > 1:
            self.cursor_y -= 1
        elif key == curses.KEY_DOWN and self.cursor_y < self.max_y :
            self.cursor_y += 1
        elif key == ord('\n'): #enter
            self.enter_flag += 1
        elif key == curses.KEY_BACKSPACE:
            self.backspace_flag = 1

        self.cursor_y_changed = (old_cursor_y != self.cursor_y)
    
    def refresh_windows(self):
        self.stdscr.clear()
        height, width = self.stdscr.getmaxyx()  # 현재 터미널 크기 가져오기
        self.create_windows()

        # 현재 크기 저장
        self.prev_height, self.prev_width = height, width


    def update_screen(self):

        if self.backspace_flag == 1:
            self.init_menu()

        if self.enter_flag == 0:
            self.ui_driver_win()

        elif self.enter_flag == 1:
            self.ui_select_win()

        elif self.enter_flag == 2 and self.apply_flag ==0:
             self.ui_select_win()

        else :
            self.ui_apply_win()
            
        if self.change_log_win == 1:
            self.ui_log_win()
            pass
        
    def load_initfile(self):
        
        config = configparser.ConfigParser()
        
        read_files = config.read('/home/cizentech/DriverMaster/src/settings.ini')
        
        if not read_files:  
            self.log_print(f"⚠️ not read src/settings.ini.")
        
        for section in config.sections():
            section_data = {"section": section, "keys": {}}
            
            for key, value in config[section].items():
                section_data["keys"][key] = value
                
            self.config_list.append(section_data)


    def ui_driver_win(self):

        idx = 0

        if self.first_driver_ui == 1 or self.cursor_y_changed:

            self.main_win.clear()
            self.main_win.addstr(1, 2, "Select Driver ")
            
            for idx, section in enumerate(self.config_list):
                section_name = section["section"] 
                if idx == self.cursor_y - 1:
                    self.main_win.addstr(idx + 3, 2, section_name, curses.color_pair(1))
                    self.select_index = idx
                else:
                    self.main_win.addstr(idx + 3, 2, section_name)
                
            # current_dir = "/boot/"
            # self.dts_list = self.list_files(current_dir)
            
            
            self.max_y = idx + 1
            self.main_win.refresh()

            self.first_driver_ui = 0
            self.cursor_y_changed = False 


    def ui_apply_win(self):

        if self.first_apply_ui == 1 or self.cursor_y_changed:

            if self.first_apply_ui ==1:
                self.cursor_y = 1

            self.main_win.clear()
            self.main_win.addstr(1, 2, "Apply Driver ")
            self.main_win.addstr(2, 2, "System needs to reboot to apply changes ")

            if self.cursor_y == 1:
                self.main_win.addstr(4, 2, "Reboot now?", curses.color_pair(1))
                self.main_win.addstr(5, 2, "Reboot later?")
            elif self.cursor_y == 2:
                self.main_win.addstr(4, 2, "Reboot now?")
                self.main_win.addstr(5, 2, "Reboot later?", curses.color_pair(1))

            self.max_y = 2

            self.cursor_y_changed = False
            self.first_apply_ui = 0

            self.main_win.refresh()

        if self.enter_flag >= 3 and self.file_idx_A != -1:
            if self.cursor_y == 1:
                try:
                    self.log_print("Rebooting system...")
                    
                    result = subprocess.run(
                        ["sudo", "reboot"],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        universal_newlines=True
                    )
                    
                    if result.returncode != 0:
                        self.log_print(f"Reboot failed: {result.stderr.strip()}")
                except Exception as e:
                    self.log_print(f"Error during reboot: {str(e)}")
                self.init_menu()
            else:
                self.init_menu()

        
    def find_module(self):
        
        self.main_win.clear()

        #source_dir = "/usr/lib/modules/5.15.148-tegra/updates/drivers/media/i2c"
        source_dir = "./test/module/"

        if not os.path.exists(source_dir):
            self.log_print(f"Directory not found: {source_dir}")
            return -1

        file_list = self.list_files(source_dir)
        
        self.file_idx_A = -1
        self.file_idx_B = -1
        
        selected_config = self.config_list[self.select_index]
        selected_name = selected_config["section"]
        
        self.main_win.addstr(1, 2, f"Select {selected_name}")
        
        self.dual_value = int(selected_config["keys"].get("dual", "0"))
        self.dtb_value = selected_config["keys"].get("dtb", "")
        
        if self.dual_value == 1:
            moduleA_value = selected_config["keys"].get("module_a", "")
            moduleB_value = selected_config["keys"].get("module_b", "")

            for idx, file_name in enumerate(file_list):
                if file_name == moduleA_value:
                    self.file_idx_A = idx
                    self.module_name_A = file_name  # Fixed variable name
                    self.log_print(f"Found module_a: {file_name} at index {idx}")
                    
                elif file_name == moduleB_value:
                    self.file_idx_B = idx
                    self.module_name_B = file_name
                    self.log_print(f"Found module_b: {file_name} at index {idx}")
                    
            # Fixed logical OR operator (| should be or)
            if self.file_idx_A < 0 or self.file_idx_B < 0:
                self.log_print(f"Could not find modules. file_idx_A={self.file_idx_A}, file_idx_B={self.file_idx_B}")
                return -1
        else:
            moduleA_value = selected_config["keys"].get("module", "")
            self.log_print(f"Looking for module: {moduleA_value}")
            
            for idx, file_name in enumerate(file_list):
                if file_name == moduleA_value:
                    self.file_idx_A = idx
                    self.module_name_A = file_name
                    self.log_print(f"Found module: {file_name} at index {idx}")
                    break
                    
            if self.file_idx_A < 0:
                self.log_print(f"Could not find module: {moduleA_value}")
                return -1
            
        
                
        self.main_win.addstr(3, 2, "Find Module")
        self.main_win.addstr(5, 2, "Apply?")
        self.main_win.refresh()
    
        self.first_select_ui = 0
        

    def ui_select_win(self):

        if self.first_select_ui == 1:
            error = self.find_module()
            if error is -1:
                self.init_menu()

        if self.enter_flag >= 2 and self.file_idx_A != -1:
            try:
                self.log_print("Appling ... ")

                if self.dual_value == 1:
                    output_dts = self.apply_dtb(self.dtb_value, f"{self.module_name_A} - {self.module_name_B}")
                    script_path = "./src/test-dual.sh"
                    output_module = self.run_script_with_module_dual(script_path, self.module_name_A, self.module_name_B, self.dtb_value)
                else:
                    output_dts = self.apply_dtb(self.dtb_value, f"{self.module_name_A}")
                    script_path = "./src/test.sh"
                    output_module = self.run_script_with_module(script_path, self.module_name_A, self.dtb_value)

                if output_dts and output_module is None:
                    self.log_print("Error: Script returned None")
                    self.output = "Error: No output"
                else:
                    #self.log_print(f"DTS output: {output_dts}")
                    #self.log_print(f"Module output: {output_module}")
                    
                    if "Apply OK" in output_module:
                        self.log_print("Apply OK")
                        self.apply_flag = 1

                    else:
                        self.log_print("error apply module.")
                    
            except RuntimeError as e:
                self.log_print(str(e))

        # Handle reboot confirmation after module application
   

    def apply_dtb(self,dtb_value,config_value):

        sh_file = "./src/change-dts.sh"
        if not os.path.exists(sh_file):
                self.log_print(f"Script not found: {sh_file}")
                return None
        
        result = subprocess.run(
                ["sudo","bash", sh_file, dtb_value,config_value],
                stdout=subprocess.PIPE,  # 표준 출력을 캡처
                stderr=subprocess.PIPE,  # 표준 에러를 캡처
                universal_newlines=True  # 문자열로 처리 
                )# 성공 시 stdout 반환
        
        if result.returncode == 0:
            return result.stdout.strip()
        else:
            # 실패한 경우 stderr 포함한 메시지 생성
            error_message = f"STDOUT1: {result.stdout.strip()}\n"
            raise RuntimeError(error_message)
        return None
    
    def run_script_with_module(self,script_path, module_name, select_file):

        try:
            if not os.path.exists(script_path):
                self.log_print(f"Script not found: {script_path}")
                return None

            result = subprocess.run(
                ["sudo","bash", script_path, module_name, select_file],
                stdout=subprocess.PIPE,  # 표준 출력을 캡처
                stderr=subprocess.PIPE,  # 표준 에러를 캡처
                universal_newlines=True  # 문자열로 처리 
                )# 성공 시 stdout 반환
            
            if result.returncode == 0:
                return result.stdout.strip()
            else:
                # 실패한 경우 stderr 포함한 메시지 생성
                error_message = f"STDOUT1: {result.stdout.strip()}\n"
                raise RuntimeError(error_message)

        except subprocess.CalledProcessError as e:
            error_message = f"STDOUT2: {e.stdout.strip()}\n"
            raise RuntimeError(error_message)
        
    def run_script_with_module_dual(self,script_path, module_name_A, module_name_B, select_file):
        try:
            if not os.path.exists(script_path):
                self.log_print(f"Script not found: {script_path}")
                return None

            result = subprocess.run(
                ["sudo","bash", script_path, module_name_A,module_name_B, select_file],
                stdout=subprocess.PIPE,  
                stderr=subprocess.PIPE,  
                universal_newlines=True  
                )
            
            if result.returncode == 0:
                return result.stdout.strip()
            else:
                # 실패한 경우 stderr 포함한 메시지 생성
                error_message = f"STDOUT1: {result.stdout.strip()}\n"
                raise RuntimeError(error_message)

        except subprocess.CalledProcessError as e:
            error_message = f"STDOUT2: {e.stdout.strip()}\n"
            raise RuntimeError(error_message)

    def init_menu(self):
        self.enter_flag = 0
        self.backspace_flag = 0
        self.first_driver_ui = 1
        self.first_select_ui = 1
        self.first_apply_ui = 1
        self.cursor_y = 1

    def log_print(self, text):

        lines = text.split("\n")

        for line in lines:
            line = line.strip()
            if line:   
                self.log_idx += 1

                if self.log_idx >= 10:
                    self.log_buffer.pop(0)  # 가장 오래된 로그 제거

                self.log_buffer.append(line)

        self.change_log_win = 1

    def list_files(self, directory):
        files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f))]
        return files

    def ui_log_win(self):
        
        self.log_win.clear()
        self.log_win.box()
        self.log_win.addstr(1, 2, "Log")

        for idx, text in enumerate (self.log_buffer):
            y_position = idx + 3
            self.log_win.addstr(y_position, 2, text)
        self.log_win.refresh()

        self.change_log_win = 0

def main(stdscr):
    app = MainApp(stdscr)
    app.run()

if __name__ == "__main__":
    curses.wrapper(main)

