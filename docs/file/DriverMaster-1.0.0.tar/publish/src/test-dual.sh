#!/bin/bash

MODULE_A_NAME=$1
MODULE_B_NAME=$2

echo "test-dual.sh start "

modules_folder="/etc/modules-load.d/"
#modules_folder="/home/cizentech/DriverMaster/test/module-load"
modules_file="$modules_folder/modules.conf"
modules_backup_file="$modules_folder/modules.conf-backup"


if [ ! -d "$modules_folder" ]; then
    echo "Creating directory: $modules_folder"
    mkdir -p "$modules_folder"
fi

if [ -f "$modules_file" ]; then
    if [ -f "$modules_backup_file" ]; then
        sudo rm "$modules_backup_file"
    fi                                                                                                                               
    sudo cp "$modules_file" "$modules_backup_file"

    echo "Backup created"
else
    echo "Error: $modules_folder does not exist."
    exit 1
fi

if grep -qx "$MODULE_A_NAME" "$modules_file"; then
    echo "$MODULE_A_NAME already exists in $modules_file"
else
    sudo echo "$MODULE_A_NAME" >> "$modules_file"
    echo "Added $MODULE_A_NAME"
fi

if grep -qx "$MODULE_B_NAME" "$modules_file"; then
    echo "$MODULE_B_NAME already exists in $modules_file"
else
    sudo echo "$MODULE_B_NAME" >> "$modules_file"
    echo "Added $MODULE_B_NAME"
fi

echo "Apply OK"
