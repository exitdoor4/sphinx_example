#!/bin/bash

DTS_NAME=$1
CUSTOM_CONFIG= $2
CUSTOM_LABEL="DriverMaster"

extlinux_folder="/boot/extlinux"
#extlinux_folder="/home/cizentech/DriverMaster/test/extlinux"
extlinux_file="$extlinux_folder/extlinux.conf"
extlinux_backup_file="$extlinux_folder/extlinux.conf.DriverMaster-backup"

echo "change-dts.sh start with"

if [ -f "$extlinux_file" ]; then
    if [ -f "$extlinux_backup_file" ]; then
        sudo rm "$extlinux_backup_file"
    fi
    sudo cp "$extlinux_file" "$extlinux_backup_file"
    echo "Backup created: $extlinux_backup_file"
else
    echo "Error: $extlinux_file does not exist."
    exit 1
fi

if grep -q "^LABEL $CUSTOM_LABEL" "$extlinux_file"; then
    echo "Found existing $CUSTOM_LABEL label, updating OVERLAYS line"
    # OVERLAYS 라인만 업데이트
    sudo sed -i "/^LABEL $CUSTOM_LABEL/,/^LABEL\|^$/s/^[[:space:]]*OVERLAYS .*/	OVERLAYS \/boot\/$DTS_NAME/" "$extlinux_file"
else
    echo "Creating new $CUSTOM_LABEL label section"
    # 새로운 라벨 섹션 추가
    cat << EOF | sudo tee -a "$extlinux_file" > /dev/null

LABEL $CUSTOM_LABEL
	MENU LABEL Custom Header Config: $CUSTOM_CONFIG
	LINUX /boot/Image
	FDT /boot/dtb/kernel_tegra234-p3768-0000+p3767-0005-nv-super.dtb
	INITRD /boot/initrd
	APPEND \${cbootargs} root=PARTUUID=0bf5e367-719e-4759-bb08-ed8b20a97e50 rw rootwait rootfstype=ext4 mminit_loglevel=4 console=ttyTCU0,115200 firmware_class.path=/etc/firmware fbcon=map:0 nospectre_bhb video=efifb:off console=tty0 nv-auto-config
	OVERLAYS /boot/$DTS_NAME
EOF

    sudo sed -i "s/^DEFAULT .*/DEFAULT $CUSTOM_LABEL/" "$extlinux_file"
fi

echo "Updated $extlinux_file with $DTS_NAME"

